local tostring = tostring
local tonumber = tonumber
local print = print
local dbg_traceback = debug.traceback
local tbl_concat = table.concat
local tbl_sort = table.sort
local tbl_remove = table.remove
local str_len = string.len
local str_byte = string.byte
local str_upper = string.upper
local str_format = string.format
local str_rep = string.rep
local str_gsub = string.gsub
local str_sub = string.sub
local str_find = string.find

-- classutil
local _M = {}

local function strltrim_(input)
    return str_gsub(input, "^[ \t\n\r]+", "")
end

local function strrtrim_(input)
    return str_gsub(input, "[ \t\n\r]+$", "")
end

local function strtrim_(input)
    input = str_gsub(input, "^[ \t\n\r]+", "")
    return str_gsub(input, "[ \t\n\r]+$", "")
end

local function strsplit_(input, delimiter)
    input = tostring(input)
    delimiter = tostring(delimiter)
    if (delimiter == "") then
        return false
    end
    local pos, arr = 0, {}
    -- for each divider found
    for st, sp in function()
        return str_find(input, delimiter, pos, true)
    end do
        table.insert(arr, str_sub(input, pos, st - 1))
        pos = sp + 1
    end
    table.insert(arr, str_sub(input, pos))
    return arr
end

function _M.printLog(tag, fmt, ...)
    local t = {
        "[",
        str_upper(tostring(tag)),
        "] ",
        str_format(tostring(fmt), ...)
    }
    print(tbl_concat(t))
end

function _M.printError(fmt, ...)
    printLog("ERR", fmt, ...)
    print(dbg_traceback("", 2))
end

function _M.printInfo(fmt, ...)
    if type(DEBUG) ~= "number" or DEBUG < 2 then
        return
    end
    printLog("INFO", fmt, ...)
end

local function dump_value_(v)
    if type(v) == "string" then
        v = '"' .. v .. '"'
    end
    return tostring(v)
end

function _M.dump(value, desciption, nesting)
    if type(nesting) ~= "number" then
        nesting = 3
    end

    local lookupTable = {}
    local result = {}

    local traceback = strsplit_(dbg_traceback("", 2), "\n")
    print("dump from: " .. strtrim_(traceback[3]))

    local function dump_(value, desciption, indent, nest, keylen)
        desciption = desciption or "<var>"
        local spc = ""
        if type(keylen) == "number" then
            spc = str_rep(" ", keylen - str_len(dump_value_(desciption)))
        end
        if type(value) ~= "table" then
            result[#result + 1] = str_format("%s%s%s = %s", indent, dump_value_(desciption), spc, dump_value_(value))
        elseif lookupTable[tostring(value)] then
            result[#result + 1] = str_format("%s%s%s = *REF*", indent, dump_value_(desciption), spc)
        else
            lookupTable[tostring(value)] = true
            if nest > nesting then
                result[#result + 1] = str_format("%s%s = *MAX NESTING*", indent, dump_value_(desciption))
            else
                result[#result + 1] = str_format("%s%s = {", indent, dump_value_(desciption))
                local indent2 = indent .. "    "
                local keys = {}
                local keylen = 0
                local values = {}
                for k, v in pairs(value) do
                    keys[#keys + 1] = k
                    local vk = dump_value_(k)
                    local vkl = str_len(vk)
                    if vkl > keylen then
                        keylen = vkl
                    end
                    values[k] = v
                end
                tbl_sort(
                    keys,
                    function(a, b)
                        if type(a) == "number" and type(b) == "number" then
                            return a < b
                        else
                            return tostring(a) < tostring(b)
                        end
                    end
                )
                for i, k in ipairs(keys) do
                    dump_(values[k], k, indent2, nest + 1, keylen)
                end
                result[#result + 1] = str_format("%s}", indent)
            end
        end
    end
    dump_(value, desciption, "- ", 1)

    for i, line in ipairs(result) do
        print(line)
    end
end

function _M.printf(fmt, ...)
    print(str_format(tostring(fmt), ...))
end

function _M.checknumber(value, base)
    return tonumber(value, base) or 0
end

function _M.checkint(value)
    return math.round(checknumber(value))
end

function _M.checkbool(value)
    return (value ~= nil and value ~= false)
end

function _M.checktable(value)
    if type(value) ~= "table" then
        value = {}
    end
    return value
end

function _M.isset(hashtable, key)
    local t = type(hashtable)
    return (t == "table" or t == "userdata") and hashtable[key] ~= nil
end

function _M.setmetatableindex(t, index)
    if type(t) == "userdata" then
        local peer = tolua.getpeer(t)
        if not peer then
            peer = {}
            tolua.setpeer(t, peer)
        end
        setmetatableindex_(peer, index)
    else
        local mt = getmetatable(t)
        if not mt then
            mt = {}
        end
        if not mt.__index then
            mt.__index = index
            setmetatable(t, mt)
        elseif mt.__index ~= index then
            setmetatableindex_(mt, index)
        end
    end
end

function _M.clone(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local newObject = {}
        lookup_table[object] = newObject
        for key, value in pairs(object) do
            newObject[_copy(key)] = _copy(value)
        end
        return setmetatable(newObject, getmetatable(object))
    end
    return _copy(object)
end

function _M.class(classname, ...)
    local cls = {__cname = classname}

    local supers = {...}
    for _, super in ipairs(supers) do
        local superType = type(super)
        assert(
            superType == "nil" or superType == "table" or superType == "function",
            str_format('class() - create class "%s" with invalid super class type "%s"', classname, superType)
        )

        if superType == "function" then
            assert(
                cls.__create == nil,
                str_format('class() - create class "%s" with more than one creating function', classname)
            )
            -- if super is function, set it to __create
            cls.__create = super
        elseif superType == "table" then
            if super[".isclass"] then
                -- super is native class
                assert(
                    cls.__create == nil,
                    str_format(
                        'class() - create class "%s" with more than one creating function or native class',
                        classname
                    )
                )
                cls.__create = function()
                    return super:create()
                end
            else
                -- super is pure lua class
                cls.__supers = cls.__supers or {}
                cls.__supers[#cls.__supers + 1] = super
                if not cls.super then
                    -- set first super pure lua class as class.super
                    cls.super = super
                end
            end
        else
            error(str_format('class() - create class "%s" with invalid super type', classname), 0)
        end
    end

    cls.__index = cls
    if not cls.__supers or #cls.__supers == 1 then
        setmetatable(cls, {__index = cls.super})
    else
        setmetatable(
            cls,
            {
                __index = function(_, key)
                    local supers = cls.__supers
                    for i = 1, #supers do
                        local super = supers[i]
                        if super[key] then
                            return super[key]
                        end
                    end
                end
            }
        )
    end

    if not cls.ctor then
        -- add default constructor
        cls.ctor = function()
        end
    end
    cls.new = function(...)
        local instance
        if cls.__create then
            instance = cls.__create(...)
        else
            instance = {}
        end
        setmetatableindex(instance, cls)
        instance.class = cls
        instance:ctor(...)
        return instance
    end
    cls.create = function(_, ...)
        return cls.new(...)
    end

    return cls
end

local iskindof_
iskindof_ = function(cls, name)
    local __index = rawget(cls, "__index")
    if type(__index) == "table" and rawget(__index, "__cname") == name then
        return true
    end

    if rawget(cls, "__cname") == name then
        return true
    end
    local __supers = rawget(cls, "__supers")
    if not __supers then
        return false
    end
    for _, super in ipairs(__supers) do
        if iskindof_(super, name) then
            return true
        end
    end
    return false
end

function _M.iskindof(obj, classname)
    local t = type(obj)
    if t ~= "table" and t ~= "userdata" then
        return false
    end

    local mt
    if t == "userdata" then
        if tolua.iskindof(obj, classname) then
            return true
        end
        mt = tolua.getpeer(obj)
    else
        mt = getmetatable(obj)
    end
    if mt then
        return iskindof_(mt, classname)
    end
    return false
end

return _M