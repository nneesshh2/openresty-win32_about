return require("lapis_appconfig").getConfigName()
