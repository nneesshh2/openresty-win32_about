local b = require "bootstrap"
--[[]]
-- require("test_protodb")
-- require("serv.dhcp_app").serve()
require("serv.mygate_app").serve()

--[[]]
