return [[require "lapis.config" ("development", {
  server = "cqueues";
})
]]
