return require("lapis.nginx.cache")
