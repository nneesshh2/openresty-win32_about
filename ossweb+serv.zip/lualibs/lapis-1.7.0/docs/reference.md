



    Welcome to the new documentation

    Here are the files that need to be done checked

    x  actions.md - moon + lua
    x  command_line.md - either
    x  configuration.md - either (has sub pages)
    x  database.md - moon + lua
    x  exception_handling.md - moon + lua
    x  getting_started.md - either (needs links)
    x  html_generation.md - moon
    x  input_validation.md - moon + lua
    x  lapis_console.md - moon + lua
    .  lua_getting_started.md
    .  moon_getting_started.md
    x  testing.md - moon + lua
    x  utilities.md - moon + lua

    need to write:
    * views for lua (etlua detailed guide)

    -- convert all the headers to the proper depths
    -- add missing links between pages, look for # links or [0]

<div class="footer">
  <a href="http://leafo.net/lapis">&laquo; Go To Homepage</a>
  &middot;
  <a href="https://github.com/leafo/lapis">GitHub Repository</a>
  &middot;
  <a href="https://github.com/leafo/lapis/issues">Issues Tracker</a>
</div>

